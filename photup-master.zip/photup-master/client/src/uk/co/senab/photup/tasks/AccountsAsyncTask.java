/*
 * Copyright 2013 Chris Banes
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package uk.co.senab.photup.tasks;

import com.facebook.android.FacebookError;

import org.json.JSONException;

import android.content.Context;
import android.os.AsyncTask;

import java.lang.ref.WeakReference;
import java.util.List;

import uk.co.senab.photup.facebook.FacebookRequester;
import uk.co.senab.photup.listeners.FacebookErrorListener;
import uk.co.senab.photup.model.Account;

public class AccountsAsyncTask extends AsyncTask<Void, Void, List<Account>> {

    public static interface AccountsResultListener extends FacebookErrorListener {

        public void onAccountsLoaded(List<Account> friends);
    }

    private final WeakReference<Context> mContext;
    private final WeakReference<AccountsResultListener> mListener;

    public AccountsAsyncTask(Context context, AccountsResultListener listener) {
        mContext = new WeakReference<Context>(context);
        mListener = new WeakReference<AccountsResultListener>(listener);
    }

    @Override
    protected List<Account> doInBackground(Void... params) {
        Context context = mContext.get();
        if (null != context) {
            Account account = Account.getAccountFromSession(context);
            if (null != account) {
                try {
                    FacebookRequester requester = new FacebookRequester(account);
                    return requester.getAccounts();
                } catch (FacebookError e) {
                    AccountsResultListener listener = mListener.get();
                    if (null != listener) {
                        listener.onFacebookError(e);
                    } else {
                        e.printStackTrace();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }

    @Override
    protected void onPostExecute(List<Account> result) {
        super.onPostExecute(result);

        Context context = mContext.get();
        if (null != context) {
            if (null != result) {
                Account.saveToDatabase(context, result);
            } else {
                result = Account.getFromDatabase(context);
            }
        }

        AccountsResultListener listener = mListener.get();
        if (null != result && null != listener) {
            listener.onAccountsLoaded(result);
        }
    }

}
